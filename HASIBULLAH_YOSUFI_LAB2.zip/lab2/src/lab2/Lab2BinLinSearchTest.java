package lab2;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * This class is the main class that will print menu option for user and manipulate the methods of linear and binary 
 * Student Name: Hasibullah Yosufi
 * Student Number: 041012318
 * Course: CST8130 - Data Structures
 * CET-CS-Level 3
 * @author Hasibullah Yosufi. 
 * 
  */
public class Lab2BinLinSearchTest {
	

	public static void main(String[] args) {
		
		 int numArr[]=new int[30];
		BinaryLinearSearch bin=new BinaryLinearSearch();
		Scanner input=new Scanner(System.in);
		
		
		
		boolean cond=true;
		try {
		do 
		{
			System.out.println("Select your option in the menu");
			System.out.println("1.Initialize and populate an array of 30 random integers");
			System.out.println("2.Perform recursive binary and linear search");
			System.out.println("3.Perform iterative binary and linear search");
			System.out.println("4.Exit");
					
					
					
					
			
			System.out.print(">");
			int choice=input.nextInt();
			switch(choice) 
			{
			case 1:
				bin.generatRandomsInts(numArr);
				break;
			case 2:
				int start=0;
				int end=numArr.length-1;
				System.out.print("Please enter an integer value to search: ");
				int userInput=input.nextInt();
				bin.recursiveBinarySearch(numArr, start, end, userInput);
				bin.recursiveLinearSearch(numArr, start, end, userInput);
				bin.remainingElements(numArr, userInput);
				break;
			case 3:
				System.out.print("Enter the number: ");
				int usserInput=input.nextInt();
				bin.iterativeLinearSearch(numArr, usserInput);
				int index=bin.iterativeBinarySearch(numArr, usserInput  );
				System.out.println();
				System.out.println("Your search key is at index: "+index);
				break;
			case 4:
				cond=false;
				input.close();
			}
		}while(cond);
		}catch(IllegalArgumentException ill) {
			System.err.print("Please choce between 1 to 4");
			input.next();
		}catch(InputMismatchException inps) 
		{
			System.err.println("********Input mismatch Exception*****");
			
		}
		
		
		
		
		
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		int a []=new int[10];
//		a[0]=12;
//		a[1]=12;
//		a[2]=12;
//		a[3]=12;
//		a[4]=12;
//		a[5]=12;
//		a[6]=12;
//		a[7]=12;
//		a[8]=12;
//		a[9]=12;
//		
//       for(int i=0; i<a.length;i++) {
//    	   System.out.println(i);
//    	 // System.out.println(System.currentTimeMillis());
//       }
	}

}
