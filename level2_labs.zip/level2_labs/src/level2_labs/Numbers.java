package level2_labs;

public class Numbers {
	
	
	private int[] numbers;
	private int[][] squares;
	//int[] c= new int[12], dc= new int[123];
	
	
	
	
	public Numbers(int row, int col) 
	{
		squares=new int[row][col];
	}
	
	
	public Numbers(int Size) {
		numbers=new int[Size];
	}

	
	public void generateNumbers() 
	{
		
		for (int i=0;i<numbers.length;i++) 
		{
			
			numbers[i]=1*i;
			
			
		}	
		
	}
	
	
	public void printNumbers() 
	{
		for (int i:numbers)
		{
			System.out.print(i+" ");
		}
		System.out.println();
	}

	
	
	//Method that Print 2d array
	public void printIndices() 
	{
		for (int i=0; i<squares.length;i++)
		{
			for (int j=0;j<squares.length;j++)
			{
				System.out.printf("%5d,%d",i,j );
			}
			System.out.println("\n");
		}
	}
	
	
	
	//Method the generate numbers in positions
	public void generateSquares() 
	{
		for (int i=0;i<squares.length;i++) 
		{
			for(int j=0;j<squares.length;j++)
			{
				
				squares[i][j]=((10*i)+j);  
				
				
			}
			
			
		}
	}
	
	public void printSquares() 
	{
		for (int i=0; i<squares.length;i++)
		{
			for (int j=0;j<i;j++)
			{
				System.out.printf("%5d", squares[i][j]*=squares[i][j]);
			}
			System.out.println("\n");
		}
	}
	
	
	
	
	
	
	public void printStarsPattern1() 
	{
		for (int i=0; i<squares.length;i++)
		{
			for (int j=0;j<i;j++)
			{
				System.out.printf("%4s","*");
			}
			System.out.println("\n");
		}
	}
	
	
	
	
	
	
	
	public void printStarsPattern2() 
	{
		for (int i=squares.length; i>0;i--)
		{
			for (int j=0;j<i;j++)
			{
				System.out.printf("%4s","*");
			}
			System.out.println("\n");
		}
	}

}
