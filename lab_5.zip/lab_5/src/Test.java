import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Paths;

//public class Test {
//
//	public static void main(String[] args)  {
		
//		System.out.println("hello ");
//		
//		Scanner input=new Scanner(System.in);
//		
//		System.out.print("Enter name: ");
//
//		
//		String name=input.next();
//		System.out.println("Enter size ");
//		int size=input.nextInt();
//		
//		College c=new College(name,size);
//		boolean ga=true;
//		do {
//		System.out.print("1.Read from user\n2.print user\n3. exit");
//		int useri=input.nextInt();
//		if(useri==1) 
//		{
//			c.ReadStudentsDetails(input);
//		}
//		else if (useri==2) {ga=false;}
//		}while (ga);
		
		//File myFile = new File("D:\\jim\\dd.txt");
		
	
//		 
//		File fe=new File();
//		FulltimeStudent ffe=new FulltimeStudent();
//		
//		fe.openFile();
//		fe.readFile();
//		//ffe.printInfo();
//		fe.close();
		
		
//		String jon="hasibshafiq.121@gmial.com";
//		String[] c=jon.split("@");
//		System.out.println(c[1]);
		
		
//}
//
//}
