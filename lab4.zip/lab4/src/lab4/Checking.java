package lab4;


/**
 * This Checking class inherits from Account class and implement its abstract method
 * to update account balance by subtracting current balance from monthly fees
 * */
public class Checking extends Account {


	// Declaring instance variable fees
	protected double fees;

	//Constructor that initialize fees to 13.50 monthly fees
	protected Checking() {
		fees=13.50;
	}

	/**
	 * This method calls its super class updateBalance method 
	 * to update current balance by subtracting monthly fees
	 * 
	 * @return void
	 *  
	 * */
	@Override
	protected void updateBalance() {

		super.balance-=fees;      //calling balance field from parent class Account and subtracting monthly fees
		Math.round(super.balance);//calling method from Math class so that the answer will rounded to two decimal 
	}

}
