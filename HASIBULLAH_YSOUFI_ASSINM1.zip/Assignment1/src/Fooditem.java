import java.util.*;

/**
 * This class act as parent class with generic fields methods that read and save to its fields
 * 
 * @author yosu0001
 * @since 2021-10-02
 * @version 1.11
 * 
 * 
 * */
public class Fooditem {
	
	private int itemCode;//for item code
	private String itemname;
	private float itemPrice;
	private int itemQuantityinStock;
	private float itemCost;
	
	
	/**
	 * Default constructor(no argument)
	 * 
	 * */
	public Fooditem() 
	{
		
	}
	
	
	/**
	 * This method return string format of fields to print all those information
	 * 
	 * 
	 * 
	 * */
	public String toString() 
	{
		String print= "[ item: "+this.itemCode+" "+this.itemname+" "+this.itemQuantityinStock
				+" price: $"+String.format("%.2f", this.itemPrice)+" cost: $"+String.format("%.2f", this.itemCost);
		
		return print;
	}
	
	
	
	/**
	 * This method checks the item code of objcet passed in its parameter return true if item code match else false
	 * @param item: Fooditem
	 * @return boolean
	 * 
	 * 
	 * */
	public boolean isEqual(Fooditem item) 
	{
		if (item.itemCode==this.itemCode) {
		return true;
		
		}else 
			return false;
	}

	
	/**
	 * This method ask for user input to fill the class data fields and return true after successful input
	 * @param input: Scanner
	 * @return boolean
	 * 
	 * 
	 * 
	 * */
	public boolean addItem(Scanner input) 
	{
		boolean condition=false;//boolean condition for the while loop and return true after successful input
		
		while (!condition) //while loop start
		{
			try {
			System.out.print("Enter the code for the item: ");
			this.itemCode=input.nextInt();//input for the itemcode
			input.nextLine();
			if(itemCode<0)               //if item code is less than 0 throws illegal argument exception
			{
				throw new IllegalArgumentException("Invalid input");
			}
			System.out.print("Enter the name of the item: ");
			this.itemname=input.nextLine();
			
			System.out.print("Enter the quantity for the item: ");
			this.itemQuantityinStock=input.nextInt();//if quantity is 0 or less thorws exception
			if(itemQuantityinStock<=0) 
			{
				throw new IllegalArgumentException("Invalid input");
			}
			
			System.out.print("Enter the cost of the item: ");
			this.itemCost=input.nextFloat();
			if(itemCost<=-1)                  //if item cost is -1 or less throw exception
			{
				throw new IllegalArgumentException("Invalid input");
			}
			
			System.out.print("Enter the sales price of the item: ");
			this.itemPrice=input.nextFloat();
			if(itemPrice<=-1)              //if item price is -1 or less throw exception
			{
				throw new IllegalArgumentException("Invalid input");
			}
			condition=true;
			}catch(InputMismatchException inp) 
			{
				System.out.println("Invalid entry");
				input.next();
				
			}catch(IllegalArgumentException illeg) 
			{
				System.out.println(illeg.getMessage());//catch for illegal exception
				
				
			}
			
		}
		
		return condition;//return true after successful condition	
	}
	
	
	
	
	/**
	 * This method update the amount item quantity return true if quantity is >= than 0
	 * Return false if item quantity is less than 0
	 * @param amount: int
	 * @return void
	 * 
	 * 
	 * 
	 * */
	public boolean updateitem(int amount) 
	{
		
		
		
		if (this.itemQuantityinStock<(amount*-1)) 
		{
			return false;
		}else
			this.itemQuantityinStock+=amount;
			return true;
		
	}//end of the method
	
	
	/**
	 * This method read valid number from the user to set that number for the item code return true if successful
	 * 
	 * 
	 * */
	public boolean inputCode(Scanner input) 
	{
		boolean cond=false;//return true after successful data reading from user
		while(!cond) {
		try {
			System.out.print("Enter the code for the item: ");
			
			if(input.hasNextInt()) {//For more bullet proffing the code check the scanner for integers else give invalid input
				
			this.itemCode=input.nextInt();//item code reads from user
			
			if(this.itemCode<0)       //if user input is less than 0 throw exception 
			{
				throw new IllegalArgumentException("Invalid input");
			}
			cond=true;  //return true after successful input from user
		}else
		{
			System.out.println("Invalid input");//if input is not integer prompt invalid input
			input.next();//ask user for another input
		}
		}catch(IllegalArgumentException illg) //catch statemet for illegal argument exception
		{
			System.out.println(illg.getMessage());
			
		}
		
	
	}//End of while loop
	
		return cond;// return condition false if reading from user was not a success
	
	}//end of the method
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
	
	
	
	
	
	

