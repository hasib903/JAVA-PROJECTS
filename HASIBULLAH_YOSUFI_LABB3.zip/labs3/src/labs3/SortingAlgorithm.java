package labs3;
import java.util.Scanner;
import java.util.Arrays;
import java.security.SecureRandom;


/**
 * This class contains the method that use linear and binary method to find search key
 * Student Name: Hasibullah Yosufi
 * Student Number: 041012318
 * Course: CST8130 - Data Structures
 * CET-CS-Level 3
 * @author/Professor James Mwangi PhD. 
 * 
  */
public class SortingAlgorithm {

	
	
	
	
	
	private int linerTemp;          //Variable is used to hold temporary value for linear search
	private Scanner input;         //Scanner for the user
          
	
	
	private int midPoint;             //variable that hold the mid point of array index
	private SecureRandom secRand=new SecureRandom();//Create and initialize secure random object

	//private int numArr[]=new int[30];//integer array that have size of 30 for binary, linearSearch
	
	
	

	

	
	
	
	
	/**
	 * This method takes an array and the search key and use binary search to find search key
	 * It uses iterative binary search algorithm
	 * 
	 * @param array: integer
	 * @param serKey: integer
	 * 
	 * @return middle: integer
	 * @return -1
	 * */
	public int iterativeBinarySearch(int [] array,int serKey) 
	
	{
		int first;                 //variable to hold first index of array in binary search
		int last;
	       //initializing instance array variable to the method parameter array
		first=0;              //initializing the first index of array as zero
		last=array.length-1; // last index of array which is its length-1
		while(first<=last)   //iterative search until search key is found
		{
		 int midPoint=(first+last)/2;//midPoint index is the length of array/2 until to find serKey

			if(array[midPoint]==serKey)      //if midPoint index is equal to search key than return the index
			{
				return midPoint;
			}else if(array[midPoint]>serKey) //if midPoint index is greater than serKey than disregard the left part 
			{
				last=midPoint-1;
			}else if(array[midPoint]<serKey) //if midPoint is less than midPoint than disregard the right part of array
			{
				first=midPoint+1;
			}//end if else
			
		}//end of while loop
		return -1;                           //if the search key is not found than return -1; 

	}//end of the method 
	
	
	
	
	
	
	
	

	

	/**
	 * This method generate secure random numbers from java.Security class
	 * @param array: integer[]
	 * 
	 * **/
	public int[] generatRandomsInts(int [] array) 
	{
		//for loop to populate every index of array with random numbers
		for (int i=0;i<array.length;i++) 
		{
			array[i]=secRand.nextInt(1000-20)+20;//random numbers should be up to 98
			
			
		}
		System.out.print("Unsorted array: ");//output the message 
		System.out.print(Arrays.toString(array)+"\n");//unsorted array to the console
		

//		System.out.print("Sorted array using bubble sort: ");
//		
//	    long start=System.nanoTime();
//		this.quickSort(array, 0, array.length-1);
//		long end=System.nanoTime();
//		
//		
//		this.printArray(array);//print sorted array
//		System.out.println();
//		System.out.println("Time in nano Second: "+(end-start)+" nano");
//		System.out.println("Time in milli Second: "+(end-start)/1000000+" millis");
//		System.out.println();
		
		return array;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * This method will sort the numbers of array using bubble algorithm
	 * @param arr: integer
	 * */
	public void bubbleeSort(int arr[]) 
	{
		int arrLen=arr.length;
		for (int i=0;i<arrLen-1;i++) 
		
			for (int j=0;j < arrLen-i-1; j++) 
			
				if (arr[j] > arr[j+1]) 
				{
					int temp=arr[j];
					arr[j]= arr[j+1];
					arr[j+1]=temp;
				}//end of if statement
			
			
			
		
		
	}//end of bubble sort
	
	
	
	
	
	
	

    /**
     * This method will print the elements of the array
     * @param arr: integer[]
     * @return void
     * 
     * */
  public  void printArray(int arr[])
    {
        int n = arr.length;
        for (int i=0; i<n; ++i)
            System.out.print(arr[i] + ", ");
        System.out.println();
    }//end of print method
	
	
	
	/**
	 * This method will sort the numbers of array using insertation sort algorithm
	 * 
	 * 
	 * @param arr: integer[]
	 * @return: void
	 * */
  public void InsertationSort(int arr[]) 
  {


	  int len=arr.length;//variable for the length of array
	  for(int i=1;i<len;i++) //making a point to the array putting i as first index of array
	  {
		  int key=arr[i];//initializing key to the first index of array
		  int j=i-1;     //variable key to hold the preposition of array
		  while(j>=0 && arr[j]>key) //if the chosen index array is bigger than its preposition than do the insertation sort
		  {
			  arr[j+1]=arr[j];//switching values and sort ascending order
			  j-=1;//j is equal to its current value minus one to keep the unsorted array in one part

		  }
		  arr[j+1]=key;//if preposition of the array is not bigger keep the value and not switch


	  }


  }	


	
	
	
	
	
	
	
	/**
	 * This method will sort the numbers of array using selection algorithm
	 * * @param arr: integer[]
	 * @return: void
	 * */
	public void SelectionSort(int arr[]) 
	{
		int len=arr.length;//variable for the length of array
		for(int i=0;i<len-1;i++) //for loop to keep the iterating the array finding minimum value and swip it
		{
			int index=i;        //variable index to help to keep the position array
			for(int j=i+1;j<len;j++) //nested for loop to look for minimum value
			{
				if(arr[j]<arr[index]) 
				{
					index=j;
				}
				int smaller=arr[index];//smaller number is in index position of chlase
				arr[index]=arr[i];
				arr[i]=smaller;
			}
		}
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * This method will merge the sorted arrays
	 * @param arr: integer[]
	 * @param lft: integer
	 * @param midd: integer
	 * @param rght: integer
	 * 
	 * @return void
	 * */
	private void mergeSort(int arr[],int lef, int midd, int rght) 
	{
		int sSub1=midd-lef+1;
		int sSub2=rght-midd;
		
		int left[]=new int[sSub1];
		int right[]=new int[sSub2];
		
		for(int i=0;i<sSub1;i++) 
		{
			left[i]=arr[lef+i];;
			
		}
		for(int i=0;i<sSub2;i++) 
		{
			right[i]=arr[midd+1+i];
		}
		
		//initial indexes of subarrays
		int i=0;
		int j=0;
		
		int k=lef;//initial the index of subarray 
		
		while(i<sSub1 &&j<sSub2) 
		{
			if(left[i]<=right[j]) 
			{
				arr[k]=left[i];
				i++;
			}
			else {
				arr[k]=right[j];
				j++;
			}
			k++;
		}
		
		//copy remaining elemtents of left subarray 
		while(i<sSub1) {
			arr[k]=left[i];
			i++;
			k++;
		}
		
		while(j<sSub2) //Copy the remaining elements to the right[] sub array
		{
			arr[k]=right[j];
			j++;
			k++;
		}
		
	}
	
	
	/**
	 * This method will sort the numbers of array using merge algorithm
	 * @param arr: integer[]
	 * @param left: integer
	 * @param right: integer
	 * 
	 * @return void
	 * */
	
	public void merge(int []arr, int left, int right) 
	{
		
		if(left<right) 
		{
			int mid=(left+(right-1))/2;//find the middle point
			
			//sort the split array
			merge(arr,left,mid);
			merge(arr,mid+1,right);
			
			//calling  mergesort to sort the array
			
			mergeSort(arr,left,mid,right);
			
			
			
		}
	}
	
	
	
	
	
    /**
     * This method will swap indexes of the array is called  in partition method
     * 
     * 
     * */	
	public void swap(int [] arr, int i, int j) 
	{
		int temp=arr[i];
		arr[i]=arr[j];
		arr[j]=temp;
	}
	
	
	
	
	
	
	
	/**
	 * This method will sort the numbers of array using quick sort algorithm
	 * @param arr: integer []
	 * @param low: integer
	 * @param high: integer
	 * */
	public void quickSort(int arr[], int low,int high) 
	{
	if(low<high) 
	{
		
		int partion=partation(arr,low,high);//partion is index of partitioning index
		
		
		//recursively sort elements before and after partation
		quickSort(arr,low,partion-1);
		quickSort(arr,partion+1,high);
	}
		
	}
	
	
	/**
	 * This method will partition the array it chooses the pivot at last element
	 * it calls the swap method to swap in ascending order
	 * 
	 *@param arr: integer[]
	 *@param low: integer
	 *@param high: integer
	 *@return integer 
	 * 
	 * */
	
	private int partation(int[] arr, int low, int high)
	{
		int pivot=arr[high];
		int i=(low-1);
		
		for(int j=low;j<=high-1;j++) 
		{
			if(arr[j]<pivot) 
			{
				i++;
				swap(arr,i,j);
			}
		}
		swap(arr,i+1,high);
		return(i+1);
		
	}	
	
	
	
	
	
	/**
	 * This method use recursion algorithm to do the binary search
	 * 
	 * @param array: integer[]
	 * @param start: integer
	 * @param end: integer
	 * @param serKey: integer
	 * @return void
	 * 
	 * */
	public int recursiveBinarySearch(int [] array,int start,int end,int serKey) 
	{
		
		try {
		int middle=(start+end)/2;//middle number add first index plus last index and divide by 2
		if(array[middle]==serKey) //if middle equal to the search key than return the position of the index
		{
			System.out.println(serKey+" was found at index position "+middle+": recursive binary Search");
			nanooTime();
			millisTime();
		}else if(array[middle]>serKey) //else if middle is larger than method call itself and disregard the right part of array 
		{
			recursiveBinarySearch(array,start,middle-1, serKey);//else if middle is smaller than method call itself and disregard the left part of array 
		}else if (array[middle]<serKey) 
		{
			recursiveBinarySearch(array,middle+1,end,serKey);//else if serKey is bigger than disregard right part
		}

		}catch(Exception e)
		{
			System.out.println(-1);
		}
		
		
		int ret=-1;
		return ret;
		
		
	}//end of method
	

	
	
	
	
	
	

	
	
	
	
	
	/**
	 * This method will print the rest of elements from the array
	 * @param array: integer[]
	 * @param serKey: integer[]
	 * @return void
	 * */
	public void remainingElements(int array[],int serKey) 
	{
		int first;                 //variable to hold first index of array in binary search
		int last;
	       //initializing instance array variable to the method parameter array
		first=0;              //initializing the first index of array as zero
		last=array.length-1; // last index of array which is its length-1
		boolean cond=true;
		while(cond)   //iterative search until search key is found
		{
		 int midPoint=(first+last)/2;//midPoint index is the length of array/2 until to find serKey

			
			 if(array[midPoint]>serKey) //if midPoint index is greater than serKey than disregard the left part 
			{
				last=midPoint-1;
				for(int i=0;i<=midPoint;i++) 
				{
					System.out.printf("%d, ",array[i]);//print the rest of elements
					cond=false;
				}
			}else if(array[midPoint]<serKey) //if midPoint is less than midPoint than disregard the right part of array
			{
				first=midPoint+1;
				for(int i=first;i<=last;i++) 
				{
					System.out.printf("%d, ",array[i]);//print the rest of elements
					cond=false;
				}
			}//end if else
			
		}//end of while loop
		
		
	}//end of reminingElement method
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * This method find search key using linear search
	 * @param array: integer[]
	 * @param serKey: integer
	 * @return void
	 * 
	 * 
	 * */
	public void iterativeLinearSearch(int [] array,int serKey) 
	{
		int position=0;//varibale for position of the index 
		
		boolean cond=true;//boolean for while loop
		while(cond) 
		{
			if(array[position]==serKey) 
			{
				linerTemp=position;
				cond=false;
			}else 
			{
				position++;
			}
			
				
		}//end of while loop
		System.out.println();
		System.out.println(serKey+" was found at index position "+linerTemp+ ": Iterative Linear Search");
		nanooTime();
		millisTime();	
		
	}//end of method

	
	
	
	

	
	
	
	
	/**
	 * time in nanoo
	 * @return void
	 * 
	 * */
	
	private void nanooTime() 
	{
		
		System.out.println("Time taken in nono Second+ "+System.nanoTime());
		
	}
	
	
	
	
		
		
	
	/**
	 * 
	 * Time in millisecond
	 * @return void
	 * 
	 * */
	
	private void millisTime() 
	{
		System.out.println("Time taken in milli second "+System.currentTimeMillis()/10000000);
		
		
	}
	
	
	
	

	
	
	
	/**
	 * This method use recursive linear search to find element
	 * @param array: integer[]
	 * @param first: integer
	 * @param last: integer
	 * @param serKey: integer
	 * @return void
	 * 
	 * 
	 * */
	public void recursiveLinearSearch(int array[],int first,int last,int serKey ) 
	{
		if(array[first]==serKey) //if search key is equal to array first index than print the index
		{
			linerTemp=first;//initialize the position of found index to temporary integer linerTemp
			System.out.println(serKey+" was found at index "+linerTemp+": Linear recursive search");
			nanooTime();
			millisTime();
		}else 
		{
			recursiveLinearSearch(array,first+1,last,serKey);
			
		}
		
		
		
		
	}
}
