/**
 * CET - CS Academic Level 3
 * This class contains the dynamically allocated array and it's processing
 * Student Name: 
 * Student Number:  
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
import java.util.*;
public class Lab1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Numbers num=new Numbers();  //initializing Numbers with default constructor
		Scanner input=new Scanner(System.in); //initializing my Scanner
		boolean cond=true;                    //initializing boolean variable for do while loop condition 
		
		try { //try statement starts
			
		do {// do while loop starts
			
		//Menu option for the user to choice between different option 
		System.out.printf("%s%s%s%s%s%s","1 : Initialize a default array\n"
				,"2: To specify the max size of the array\n","3: Add value to the array\n",
				"4: Display values in the array\n","5: Display average of the values\n",
				"6: To Exit\n> ");
		
		int userChoice=input.nextInt(); //User Input for the user to chose from the above menu
		
		switch(userChoice)             //Declaring Switch Statement and userChoice as its parameter
		{
		
		case 1:
			Float[] arr=new Float[4];  //if user chose 1 it will initialize new constructor
			break;
		case 2:                       //if the user chose 2 it will initialize new Float array with user choice in length
			System.out.print("Enter new size of array: "); //asking the user for the length
			int size=input.nextInt();                     //input for the user
			Numbers numb=new Numbers(size);              //initializing the length of the new array specified by the user
			break;
		case 3:
			num.addValue(input);   //add values to the array from start 
			break;
		case 4: 	              //Show elements of each index from array numbers in Numbers class
		num.showElements();       
		break;
		case 5:                  //Calculate the average, max and min value of the array
			num.calcAverage();
			break;
		case 6:                 //if user enter 6 the program will finish
			System.out.println("Exiting....");
			cond=false;
			break;
		}
		
			
		}while(cond);//end of while do while loop
		
		}catch(InputMismatchException iop) //Catch for invalid input
		{
			System.err.println("Wrong input ");
			input.next();
			
		}catch(IllegalArgumentException ill) //catch for entering values that does not exist in menu
		{
			System.err.println("No such option");
			input.next();
		}catch (NullPointerException nll)  //catch for null index
		{
			System.err.println("Exception");
		
			
		} 
		{
			
		}

	}

}
