import java.util.Scanner;

public class Vegetable extends Fooditem{
	
	private String farmName;
	
	public Vegetable() 
	{
		
	}
	
	
	
	/**
	 * This method return String values of data it calls its super class method and over ride its own
	 * @return String
	 * 
	 * 
	 * 
	 * */
	@Override
	public String toString() 
	{
            
		
		String forPrint=super.toString()+" supplier: "+this.farmName+" ]";//add farm suuplier to string 
		
		return forPrint;
		
			
	}
	
	
	/**
	 * This method reads from keyboard and save them to parent class fields
	 * @param scanner: Scanner
	 * 
	 * 
	 * */
	@Override
	public boolean addItem(Scanner scanner) 
	{
		boolean mustReturn=false;
		
		while(!mustReturn) {
				
		super.addItem(scanner);//calling super class method
		scanner.nextLine();//for the user input to disregard line skipping
		System.out.print("Enter the name of the farm supplier: ");
		this.farmName=scanner.nextLine();
		mustReturn=true;
		
		}
		
		return mustReturn;
		
		
		
	}
	
	
	
	

}
