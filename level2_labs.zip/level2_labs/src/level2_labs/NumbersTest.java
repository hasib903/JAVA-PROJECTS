package level2_labs;

public class NumbersTest {
public static void main(String[] args) {
	Numbers n1=new Numbers(10);
	n1.generateNumbers();
	System.out.println("Printing Numbers");
    n1.printNumbers();	

	Numbers n2=new Numbers(10,10);
	n2.generateSquares();
	n2.printIndices();
	n2.printSquares();
	n2.printStarsPattern1();
	n2.printStarsPattern2();
}
}
