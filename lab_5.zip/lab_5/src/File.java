
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.*;
import java.nio.file.Paths;



public class File {
	
	//private static Scanner input;
	
	FulltimeStudent ful;//=new FulltimeStudent();
	ParttimeStudent par;//=new ParttimeStudent();
	
	private static Scanner input;
	public  void openFile() 
	{
	
		try {
			input=new Scanner(Paths.get("D:\\coke\\students.txt"));
		}catch (FileNotFoundException nfe) 
		{
			System.out.println("no such file or !!!");
		}catch (IOException ie)
		{
			System.out.println("IO exception ");
		}
		
	}


	public void readFile()
	{
	
		try 
		{

			String type=input.next();
			int stn=input.nextInt();				
			String namef=input.next();
			String lastName=input.next();
			String emial=input.next();
			int phone=input.nextInt();
			String program=input.next();
			float mark=input.nextFloat();
			float anot=input.nextFloat();
			ful=new FulltimeStudent (type,stn,namef,lastName,emial,phone,program,mark,anot);
			ful.printInfo();
			
			//	
			String tyope=input.next();
			int stnn=input.nextInt();
			String name=input.next();
			String LastName=input.next();
			String emiial=input.next();
			int phoone=input.nextInt();
			String proogram=input.next();
			float marks=input.nextFloat();
			double fees=input.nextDouble();
			float bonus=input.nextFloat();
			par=new ParttimeStudent(tyope,stnn,name,LastName,emiial,phoone,proogram,marks,fees,bonus);
	        par.printInfo();
		
			String protype=input.next();
			int studentN=input.nextInt();							
			String stuFName=input.next();
			String stulastName=input.next();
			String stuemial=input.next();
			int studphone=input.nextInt();
			String stuprogram=input.next();
			float stumark=input.nextFloat();
			float stuanot=input.nextFloat();
			ful=new FulltimeStudent(protype,studentN,stuFName,stulastName,stuemial,studphone,stuprogram,stumark,stuanot);
			ful.printInfo();
		

		}catch (InputMismatchException in) 
		{
			System.out.println("oha nooo");
			
		}catch (IllegalArgumentException ilg) 
		{
		 System.out.println("dmen "); 
		}
		
	}//end of readreadFile method
	
	

	public void close() {
		if (input !=null) {
			input.close();
		}
	}
		
	
	}