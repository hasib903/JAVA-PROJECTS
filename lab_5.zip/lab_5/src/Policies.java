
/**
 * This interface is used in Students class with method
 *  to calculate GPA, and constant variables 
 *  
 *
 * 
 * @author hasibyosufi
 * 
 * @version 1.8
 * 
 * @Since 2.0
 * 
 * 
 * 
 * */




public interface Policies {
	
	
	 static final int MAX_MARKS=100;
	 static final double MAX_GPA=4.0;
	 
	 /**
	  * calculateGPA method will be used to read user marks 
	  * and calculate their GPA
	  *   
	  * @param marks: double
	  * @return void
	  * 
	  */
	 public void calculateGpa(double [] marks);

}
