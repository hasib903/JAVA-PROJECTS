


/**
 * Student class exteds Person and implements Poilices
 * 
 * This class read college name, Student information, user marks 
 * calculate the GPA and print the Student details. 
 * 
 * 
 * @author hasibyosufi
 * 
 * @version 1.8
 * @since 2.0
 * 
 * 
 * 

 * 
 * 
 * 
 */





import java.util.Scanner;

public class Students extends Person implements Policies {
	
	protected String programType;
	protected int studentNumber;
	protected String programName;
	protected double gpa;
	
	
	
	
	
/**
 * This method reads Student information 
 * 
 * @return void
 * 
 * @param input: Scanner
 * */
	
	@Override
	public void readInfo(Scanner input) {
		
		System.out.print("Enter program name: ");
		this.programName=input.next();
		System.out.print("Enter student number: ");
		this.studentNumber=input.nextInt();
		System.out.print("Enter student first name: ");
		this.fName=input.next();
		System.out.print("Enter student last name: ");
		this.lName=input.next();
		System.out.print("Enter email Id: ");
		this.email=input.next();
		System.out.print("Enter phone number: ");
		this.phone=input.nextLong();
		readMarks(input);
		
		
		
	}
	
	
	int counter=1;//variable to be on track of the number of students
	
	/**
	 * This method read students marks accept save them in array of double 
	 * will calculate the totlal gpa of the marks.
	 * @return void
	 * 
	 * @param input: Scanner
	 * */
	private void readMarks(Scanner input) 
	{
		System.out.print("Enter the number of Courses: ");
		int numCourse=input.nextInt();
		double [] numOfCourses=new double [numCourse];
		for (int i=0;i<numOfCourses.length;i++) 
		{
			System.out.printf("%s%d%s","Enter mark ",counter,": ");
			numOfCourses[i]=input.nextDouble();
			counter++;
		
			
		}
		calculateGpa(numOfCourses);
	}
	

	@Override
	public void printInfo() {
		System.out.printf("   %4s|    %4d|%7s%9s | %16s| %12d| %3.2f| ",programName,studentNumber,fName,lName,email,phone,gpa);
		
	}


    /**
     * Calculate the GPA by reading marks from user in array of double
     * 
     * @param marks[]: double
     * @return void
     * 
     * 
     * */

	@Override
	public void calculateGpa(double[] marks) {
		//double variable to calculate the sum of the marks 
		double sum=0;
		for (int i=0;i<marks.length;i++) 
		{
			sum+=marks[i];
		}
//		System.out.println("Sum IS: "+sum);
//		System.out.println("The length is: "+marks.length);
//		sum=sum/marks.length;
//		System.out.println("Sum is: "+sum);
		gpa=sum/(marks.length*MAX_MARKS)*MAX_GPA;
		
		
	}


}
