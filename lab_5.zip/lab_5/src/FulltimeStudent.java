/**
 * This class is for full time students it inherits its super class Student
 * with addition tuition fees in instance variables
 * 
 * @author hasibyosufi
 * @version 1.8
 * @since 2.0
 * 
 * */



import java.util.Scanner;
import java.nio.file.Paths;
public class FulltimeStudent extends Students{
	
	//declaring my instance variable tuition Fees double 
	private double tuitionFees;
	
	protected FulltimeStudent() {}//default construcort 
	
	
	/**
	 * Parameterized  constructor for the user to invoke data from file
	 * 
	 * @param type: String
	 * @param stuNum: int
	 * @param fName: String
	 * @param lName: String
	 * @param email: String
	 * @param stuNum: long
	 * @param program: String
	 * @param gpa: double
	 * @param fees: double
	 * 

	 * 
	 * */
	
	// parameterized constructor for Full time student to invoke variables wchich scanner read is
	protected FulltimeStudent(String type,int studNum,String fName,String lName, String email,long stuNum,String program, double gpa,double fees) 
	{
		// invoking all of the arguments into the instance variables 
		super.programType=type;
		super.studentNumber= studNum;
		super.fName=fName;
		super.lName=lName;
		super.email=email;
		super.phone=stuNum;
		super.programName=program;
		super.gpa=gpa;
		this.tuitionFees=fees;
		
		
	}
	
	
	
	
	
	
	
	/**
	 * This method reads student informations and marks.
	 * 
	 * It calls its super method readInfor() and then read 
	 * student's tuition fees will save it to tuition fees.
	 * 
	 * @return void
	 * */
	@Override
	
	public void readInfo(Scanner input) 
	{
		super.readInfo(input);
		System.out.print("Enter tuition fees: ");	
    	tuitionFees=input.nextDouble();
		
	}	
	
	
	/**
	 * This method print Student information and GPA
	 * 
	 * it calls its super method printInfo and then print student's tuition fees
	 * 
	 * @return void
	 * 
	 * */
	@Override
	public void printInfo() 
	{
		super.printInfo();
		System.out.printf("%7.2f| %s",tuitionFees,"\n");
	}
	
	
	

}
