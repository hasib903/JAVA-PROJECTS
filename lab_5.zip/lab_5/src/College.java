import java.util.Scanner;
import java.nio.file.Paths;
import java.io.*;
import java.util.ArrayList;
import java.util.InputMismatchException;



/**
 * This class manipulates Students (super class) and its subclasses part-time, full-time
 * 	
 * it creates object array of Students and giving choice for the user will determine 
 * full-time and part-time students
 * 
 * @author hasibyosufi
 * @version 1.8
 * 
 * @since 2.0
 * 
 * 
 * */




public class College {
	
	// Declaring my instance variables and 
	protected String name;
	protected ArrayList <Students> student=new ArrayList();
	
	
	//Declaring scanner for user to choice between part-time and full-time
	//Scanner input =new Scanner(System.in);
	
	/**
	 * The parameterized constructor to specify amount of space for students name of college
	 *
	 * @param name: String
	 * @param size: int
	 * */
	protected College(String name, int size) //Parameterized constructor to indicate the name and size of ArrayList 
	{
	  this.name=name;
	  
	  student=new ArrayList<Students> (size);//indicating size from user input
	}
	
	

	
	protected College() {}//non parameterized constructor for user
	
	
	/**
	 * This method prints name of the college in format
	 * 
	 * @return: void
	 * */
	protected void printTitle() 
	{
		System.out.println("\n==================================================================================\n");
		System.out.printf("%45s%s", " College - List of Students"+name,
				"\n==================================================================================\n");
			
	}
	
	
	

	
	int j=0;//variable for index of students students
	
	
	/**
	 * This method reads from user of from file to choose between part time and full time students and depends on user choice 
	 * - it add information into ArrayList
	 * 
	 * @return: return
	 * 
	 * @exception IllegalArgumentException
	 * @exception InputmisMatchException
	 * 
	 * */
	
	
	protected void ReadStudentsDetails(Scanner input) 
	{
		int studentcounter=1;
		boolean coon=true;
	  //putting the method in loop so it will keep reading depending on the number of students
		do {
			
	try {// try and catch block to handle poosible Exceptions 
		
		//prompt menu option for the user to choose student type (full time/part time)
		System.out.println("Enter details of student "+studentcounter+":");	
		System.out.println("===============================");
		System.out.printf("%s%s","1 - Fulltime student","\n2 - Parttime student\n" );
		System.out.print("Enter Student type: ");
		
		int type=input.nextInt();//input for the user
		
		//while loop if the user enter wrong value instead on 1 or 2 to give them wrong number
		while(!(type>=1&&type<=2))
		{
			throw new IllegalArgumentException ("wrong student type ;( ");
		}//while loop ends
		
	  input.nextLine();//input for the user to chose between options

	 if (type==1) //if user press 1 add new Full time student in ArrayList
	 {
		 student.add(new FulltimeStudent());
		 student.get(j).readInfo(input);
		 j++;
	 }//first if ==1 ends
	 
	 else if (type==2)//if user press 2 add new Part time student in ArrayList
	 {
		 student.add(new ParttimeStudent());
		 student.get(j).readInfo(input);
		 j++;
	 }//if ==2 ends
	 
     //j++;
	 studentcounter++;
	coon=false;//if not Exception happened coon become false and end the do while loop
	
	
	} catch(InputMismatchException ig)
	{
		System.err.print("Input Mismatch exception while reading student type! ");
		input.next();//input for the user to try again for invalid input
	}//end of inputMismatch catch
	
	//IllegalArgumentException catch 
    catch (IllegalArgumentException il) 
	{
    	System.out.println(il.getMessage());
    	//input.next();
	}
		} while (coon);//do while loop ends
		
	}//method ends
	
	
	
	/**
	 * This method print the details of students in format. It uses the size or ArrayList to print details of students. 
	 * 
	 * @return: void
	 * 
	 * @throws IndexOutOfBoundsException 
	 * */
	protected void printStudentDetial() 
	
	{	
			if (student.isEmpty())
			//if  ArrayList is empty throw exception no index in arraylist to print
			throw new IndexOutOfBoundsException ("######### Nothing to display ###########");
			
		   else if (!(student.isEmpty()))
		{
	  
		  printTitle();//calling print title method to print the name of College in format
		
		  System.out.printf("%s|%s|%17s|%17s|%13s|%5s|%8s|%5s", "Program","Student#"
				,"Name","Email","Phone","GPA","Fees","Credits\n"); 
		
		 //for loop to keep printing until there is no more in the ArrayList
	    for (int i=0;i<j;i++)
	    {
	    	student.get(i).printInfo(); 
        }//end of for loop
	    
	   }//end of else if 
			
	}//end of the method
	
	
    /**
     * This method will open a file that the path is specified in the scanner
     * 
     * @return void
     * @Exception FileNotFoundException
     * @Exception IOException
     * 
     * */
    static Scanner scan;//Scanner for the file to get the path and scan file
	private void openFile() 
	{
	
		try {
			scan=new Scanner(Paths.get("D:\\coke\\students.txt"));
		}catch (FileNotFoundException nfe) 
		{
			System.out.println("no such file or !!!");
		}catch (IOException ie)
		{
			System.out.println("IO exception ");
		}

		
	}//end of openFile method
	
	
	/**
	 * This method read data from specified file from Scanner it then saves all data in appropriate data types and invoke them 
	 * in Constructors of Full time / Part time
	 * 
	 * 
	 * @return void
	 * 
	 * @exception InputMismatchException
	 * @exception IllegalArgumetnException
	 * @exception Exception
	 * 
	 * */
	protected void readFile()
	{
		openFile();//calling open file method so can read from opened file
		
	
		try 
		{
			//saving all data in to its appropriate variables
			String type=scan.next();
			int stn=scan.nextInt();				
			String namef=scan.next();
			String lastName=scan.next();
			String emial=scan.next();
			int phone=scan.nextInt();
			String program=scan.next();
			float mark=scan.nextFloat();
			float anot=scan.nextFloat();

			//	//saving all data in to its appropriate variables
			String tyope=scan.next();
			int stnn=scan.nextInt();
			String name=scan.next();
			String LastName=scan.next();
			String emiial=scan.next();
			int phoone=scan.nextInt();
			String proogram=scan.next();
			float marks=scan.nextFloat();
			double fees=scan.nextDouble();
			float bonus=scan.nextFloat();

			
			//saving all data in to its appropriate variables
			String protype=scan.next();
			int studentN=scan.nextInt();							
			String stuFName=scan.next();
			String stulastName=scan.next();
			String stuemial=scan.next();
			int studphone=scan.nextInt();
			String stuprogram=scan.next();
			float stumark=scan.nextFloat();
			float stuanot=scan.nextFloat();

			
			{
				//invoking all saved variables from Scanner to Full time constructor and adding it to arraylist
				student.add(new FulltimeStudent (type,stn,namef,lastName,emial,phone,program,mark,anot));
			 j++;
			}
			{
				//invoking all saved variables from Scanner to Part time constructor and adding it to arraylist
			student.add(new ParttimeStudent (tyope,stnn,name,LastName,emiial,phoone,proogram,marks,fees,bonus));
			j++;
			}
			{	
				//invoking all saved variables from Scanner to Part time constructor and adding it to arraylist
				student.add(new FulltimeStudent (protype,studentN,stuFName,stulastName,stuemial,studphone,stuprogram,stumark,stuanot));
				j++;
			}
			


		}catch (InputMismatchException in) 
		{
			System.out.println("Invalid input");
			
		}catch (IllegalArgumentException ilg) 
		{
		 System.out.println("Illegal argruments input "); 
		}catch (Exception iee) 
		{
			System.out.println("Oh noo (; (; (; (;   ");
		}
		
	}//end of readreadFile method
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	

}
