import java.util.Scanner;

/**
 * 
 * This class extends Fooditems and and have field for size in mills call its parent class method override them
 * @author khesr
 * @since 2021-10-02
 * @version 1.8
 * 
 * 
 * */

public class Fruit extends Fooditem{


	private String orchardName;

	public Fruit() {}

	/**
	 * This method return String values of data it calls its super class method and over ride its own
	 * @return String
	 * 
	 * 
	 * 
	 * */
	@Override
	public String toString() {


		String forPrint=super.toString()+" supplier: "+this.orchardName+" ]";
		
		return forPrint;
	}


	/**
	 * This method reads orchard name from user call its super class method return true after successful reading
	 * @param Scanner: scanner
	 * @return boolean
	 *  
	 * */
	@Override
	public boolean addItem(Scanner input) 
	{
		boolean mustReturn=false;

		while(!mustReturn) {

			super.addItem(input);
			input.nextLine();//for the user input to disregard line skipping
			System.out.print("Enter the name of the orchard supplier: ");
			this.orchardName=input.nextLine();
			mustReturn=true;

		}

		return mustReturn;//return true after successful transction



	}
}
