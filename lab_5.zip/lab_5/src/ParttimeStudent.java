/**
 * 
 * Part time class inherits Students class with two instance variables
 * which will be used to read student total fees and their credits
 * 
 * @author hasibyosufi
 * @version 1.8
 * @since 2.0
 * 
 * 
 * */
import java.util.Scanner;
public class ParttimeStudent extends Students {
	
	private double courseFeesTotal;
	private double credits;
	
	
	
	
	
	public ParttimeStudent() 
	{
		
	}
	
	/**
	 * Parameterized  constructor for the user to invoke data from file and add it to arrayList
	 * 
	 * @param p: String
	 * @param stdNumber:int
	 * @param fName: String
	 * @param lName: String
	 * @param email: String
	 * @param phone: long
	 * @param programName: String
	 * @param gpa: double
	 * @param fees: double
	 * @param bonus: double
	 * 

	 * 
	 * */
	//Parameterized for part time students use 
	public ParttimeStudent(String p, int stdNumber,String fName,String lName,String email
			,int phone,String programName,double gpa,double fees,double bonus) 
	{ 
		// parameterized constructor for Full time student to invoke variables wchich scanner read is
		super.programType=p;
		super.studentNumber=stdNumber;
		super.fName=fName;
		super.lName=lName;
		super.email=email;
		super.phone=phone;
		super.programName=programName;
		super.gpa=gpa;
		this.courseFeesTotal=fees;
		this.credits=bonus;
	
		
		
	}
	
	
	
	
	
	
	
	/**
	 * This reads students information by calling its super
	 * method and the # student courses
	 * @return void
	 * 
	 *
	 * */
	@Override
	public void readInfo(Scanner input) 
	{
	//calling super method	
	super.readInfo(input);
	System.out.print("Enter total course fees: ");
	//For user input
	courseFeesTotal=input.nextDouble();
	System.out.print("Enter credits hours: ");
	
	credits=input.nextDouble();
	}
	
	
	/**
	 * This method print the details of students by calling
	 * its super method with addition courseFeesTotal and credits
	 * 
	 * @return: void
	 * 
	 * */
	@Override
	public void printInfo() 
	{
		super.printInfo();
		System.out.printf(" %.2f| %.2f|%s", courseFeesTotal,credits,"\n");
	}

}
