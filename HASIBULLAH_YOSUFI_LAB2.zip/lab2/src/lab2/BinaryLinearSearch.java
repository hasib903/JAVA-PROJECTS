package lab2;
import java.util.Scanner;
import java.util.Arrays;
import java.security.SecureRandom;

/**
 * This class contains the method that use linear and binary method to find search key
 * Student Name: Hasibullah Yosufi
 * Student Number: 041012318
 * Course: CST8130 - Data Structures
 * CET-CS-Level 3
 * @author/Professor James Mwangi PhD. 
 * 
  */
public class BinaryLinearSearch {

	private int linerTemp;               //Variable is used to hold temporary value for linear search
	private Scanner input;              //Scanner for the user
                 //Variable to hold the last index of array 

	private int midPoint;             //variable that hold the mid point of array index
	private SecureRandom secRand=new SecureRandom();

	//private int numArr[]=new int[30];//integer array that have size of 30 for binary, linearSearch

	/**
	 * This method takes an array and the search key and use binary search to find search key
	 * It uses iterative binary search algorithm
	 * 
	 * @param array: integer
	 * @param serKey: integer
	 * 
	 * @return middle: integer
	 * @return -1
	 * */
	public int iterativeBinarySearch(int [] array,int serKey) 
	
	{
		int first;                 //variable to hold first index of array in binary search
		int last;
	       //initializing instance array variable to the method parameter array
		first=0;              //initializing the first index of array as zero
		last=array.length-1; // last index of array which is its length-1
		while(first<=last)   //iterative search until search key is found
		{
		 int midPoint=(first+last)/2;//midPoint index is the length of array/2 until to find serKey

			if(array[midPoint]==serKey)      //if midPoint index is equal to search key than return the index
			{
				return midPoint;
			}else if(array[midPoint]>serKey) //if midPoint index is greater than serKey than disregard the left part 
			{
				last=midPoint-1;
			}else if(array[midPoint]<serKey) //if midPoint is less than midPoint than disregard the right part of array
			{
				first=midPoint+1;
			}//end if else
			
		}//end of while loop
		return -1;                           //if the search key is not found than return -1; 

	}//end of the method 

	/**
	 * This method generate secure random numbers from java.Security class
	 * @param array: integer[]
	 * 
	 * **/
	public void generatRandomsInts(int [] array) 
	{
		//for loop to populate every index of array with random numbers
		for (int i=0;i<array.length;i++) 
		{
			array[i]=secRand.nextInt(98);//random numbers should be up to 98
			
			
		}
		System.out.print("Unsorted array: ");//output the message 
		System.out.print(Arrays.toString(array));//unsorted array to the console
		Arrays.sort(array);                     //sort array from less to big
		System.out.println();
		System.out.print("Sorted array: ");   //print the message sorted array
		System.out.print(Arrays.toString(array));//print the sorted array
	}
	
	
	/**
	 * This method use recursion algorithm to do the binary search
	 * 
	 * @param array: integer[]
	 * @param start: integer
	 * @param end: integer
	 * @param serKey: integer
	 * @return void
	 * 
	 * */
	public void recursiveBinarySearch(int [] array,int start,int end,int serKey) 
	{
		
		
		int middle=(start+end)/2;//middle number add first index plus last index and divide by 2
		if(array[middle]==serKey) //if middle equal to the search key than return the position of the index
		{
			System.out.println(serKey+" was found at index position "+middle+": recursive binary Search");
			nanooTime();
			millisTime();
		}else if(array[middle]>serKey) //else if middle is larger than method call itself and disregard the right part of array 
		{
			recursiveBinarySearch(array,start,middle-1, serKey);//else if middle is smaller than method call itself and disregard the left part of array 
		}else if (array[middle]<serKey) 
		{
			recursiveBinarySearch(array,middle+1,end,serKey);
		}else 
		{
			System.out.println(-1);
		}
	
	}//end of method
	
	
	/**
	 * This method will print the rest of elements from the array
	 * @param array: integer[]
	 * @param serKey: integer[]
	 * @return void
	 * */
	public void remainingElements(int array[],int serKey) 
	{
		int first;                 //variable to hold first index of array in binary search
		int last;
	       //initializing instance array variable to the method parameter array
		first=0;              //initializing the first index of array as zero
		last=array.length-1; // last index of array which is its length-1
		boolean cond=true;
		while(cond)   //iterative search until search key is found
		{
		 int midPoint=(first+last)/2;//midPoint index is the length of array/2 until to find serKey

			
			 if(array[midPoint]>serKey) //if midPoint index is greater than serKey than disregard the left part 
			{
				last=midPoint-1;
				for(int i=0;i<=midPoint;i++) 
				{
					System.out.printf("%d, ",array[i]);//print the rest of elements
					cond=false;
				}
			}else if(array[midPoint]<serKey) //if midPoint is less than midPoint than disregard the right part of array
			{
				first=midPoint+1;
				for(int i=first;i<=last;i++) 
				{
					System.out.printf("%d, ",array[i]);//print the rest of elements
					cond=false;
				}
			}//end if else
			
		}//end of while loop
		
		
	}//end of reminingElement method
	
	/**
	 * This method find search key using linear search
	 * @param array: integer[]
	 * @param serKey: integer
	 * @return void
	 * 
	 * 
	 * */
	public void iterativeLinearSearch(int [] array,int serKey) 
	{
		int position=0;//varibale for position of the index 
		
		boolean cond=true;//boolean for while loop
		while(cond) 
		{
			if(array[position]==serKey) 
			{
				linerTemp=position;
				cond=false;
			}else 
			{
				position++;
			}
			
			
			
		}//end of while loop
		System.out.println();
		System.out.println(serKey+" was found at index position "+linerTemp+ ": Iterative Linear Search");
		nanooTime();
		millisTime();
		
		
		
		
	}//end of method

	
	
	private void nanooTime() 
	{
		
		System.out.print("Time taken in nono Second+ "+System.nanoTime());
		
	}
	
	private void millisTime() 
	{
		System.out.println("Time taken in milli second "+System.currentTimeMillis());
		
		
	}
	
	/**
	 * This method use recursive linear search to find element
	 * @param array: integer[]
	 * @param first: integer
	 * @param last: integer
	 * @param serKey: integer
	 * @return void
	 * 
	 * 
	 * */
	public void recursiveLinearSearch(int array[],int first,int last,int serKey ) 
	{
		if(array[first]==serKey) //if search key is equal to array first index than print the index
		{
			linerTemp=first;//initialize the position of found index to temporary integer linerTemp
			System.out.println(serKey+" was found at index "+linerTemp+": Linear recursive search");
			nanooTime();
			millisTime();
		}else 
		{
			recursiveLinearSearch(array,first+1,last,serKey);
			
		}
		
		
		
		
	}
	
	
	
	
	
	
	
}
