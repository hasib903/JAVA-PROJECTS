package level2_labs;

public class Numbers {
	
	//instance variable 1d integer array 
	private int[] numbers;
	//instance variable 2d integer array
	private int[][] squares;

	
	
	
	//constructor that accepts two parameters for 2d array
	public Numbers(int row, int col) 
	{
		squares=new int[row][col];
	}
	
	//constructor for 1d array with one parameter for arrya size
	public Numbers(int Size) {
		numbers=new int[Size];
	}

	//method for 1d array generate numbers for user input
	public void generateNumbers() 
	{
		
		for (int i=0;i<numbers.length;i++) 
		{
			
			numbers[i]=1*i;
			
			
		}	
		
	}
	
	
	//method for 1d array to print the elements
	public void printNumbers() 
	{
		for (int i:numbers)
		{
			System.out.print(i+" ");
		}
		System.out.println();
	}

	
	
	//Method that Print 2d array
	public void printIndices() 
	{
		for (int i=0; i<squares.length;i++)
		{
			for (int j=0;j<squares.length;j++)
			{
				System.out.printf("%5d,%d",i,j );
			}
			System.out.println("\n");
		}
	}
	
	
	
	//Method the generate squares of numbers
	public void generateSquares() 
	{
		for (int i=0;i<squares.length;i++) 
		{
			for(int j=0;j<squares.length;j++)
			{
				
				squares[i][j]=((10*i)+j);  
				
				
			}
			
			
		}
	}
	
	
	//method that print squares of numbers in pattern
	public void printSquares() 
	{
		for (int i=0; i<squares.length;i++)
		{
			for (int j=0;j<i;j++)
			{
				System.out.printf("%5d", squares[i][j]*=squares[i][j]);
			}
			System.out.println("\n");
		}
	}
	
	
	
	
	
	//method that print star in pattern1
	public void printStarsPattern1() 
	{
		for (int i=0; i<squares.length;i++)
		{
			for (int j=0;j<i;j++)
			{
				System.out.printf("%4s","*");
			}
			System.out.println("\n");
		}
	}
		
	//method that print stars in pattern 2
	public void printStarsPattern2() 
	{
		for (int i=squares.length; i>0;i--)
		{
			for (int j=0;j<i;j++)
			{
				System.out.printf("%4s","*");
			}
			System.out.println("\n");
		}
	}

}
