package lab4;
import java.util.Scanner;
/**
 * This abstract class Accounts contain generic information about account:
 *  account# and balance and uses Person object to ask about about personal information
 *  
 *  @author Hasibullah Yosufi
 * 
 *  @since 1.0
 *  
 *  @version 1.8
 * 
 * 
 * 
 * 
 * **/
public  class Account {
	//declaring my instance variables for account#, balance and Person object
	protected long accNumber;
	protected Person accHolder=new Person(); //initialization Person object so that can access its method and fields
	protected double balance;

	/**
	 * This method will read user's account number and personal information
	 * by calling Person class method then reads user's account balance
	 * 
	 * @param Scanner
	 * 
	 * @return void
	 * 
	 * 
	 * 
	 * 
	 * */
	protected void readAccountDetails(Scanner input) {

		System.out.print("Enter account number: "); //asking for user's account number
		this.accNumber=input.nextLong();			//waiting for user input integer

		accHolder.readPersonalDetails(input);		//calling method from Person class to that can read personal information

		System.out.print("Enter the balance: ");   //asking the user for their balance
		this.balance=input.nextDouble();		   // waiting for balance input
	}




	/**
	 * This method will print user's account's information including personal information
	 * 
	 * @return void
	 * 
	 * 
	 * */
	protected void displayAccount() 
	{
		System.out.printf(" %16d |%17s |%20s  | %12d |  %.2f%s",accNumber,
				accHolder.getName(),accHolder.getEmail(),accHolder.getPhoneNumber(),balance,"\n"); //calling getters from Person class
	}


	protected  void updateBalance() {};// abstract method for Checking and Saving class














}


