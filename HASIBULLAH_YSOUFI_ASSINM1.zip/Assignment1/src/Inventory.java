import java.util.*;

/**
 * This class play with Fooditem object act as polymorphism and methods to read and pring the fields of Fooditem
 * @author khesr
 * @since 2021-10-02
 * 
 * 
 * */
public class Inventory {

	protected Fooditem [] inventory;//array of Fooditem object
	protected int numItems=0;
	
	
	/**
	 * Default (No argument) constructor
	 * 
	 * */
	public Inventory() 
	{
		inventory=new Fooditem[10];
		
	}
	
	
	
	/**
	 * Search for the item code applied in the parameter return the index if item code is found else -1;
	 * 
	 * @param Fooditem: item
	 * @return integer
	 * */
	public int alreadyExists(Fooditem item) 
	{
		
		for(int i=0;i<numItems;i++) 
		{
			if(inventory[i].isEqual(item)){
				return i;
			}
		}
		
		return -1;
	}//method ends
	
	
	
	/**
	 * This method use polymorphism concepts and based on user choice read data from user and save it to class fields
	 * @param Scanner scanner
	 * @return boolean
	 * */
	public boolean addItem(Scanner scanner) 
	{
		boolean cond=false;
		while(!cond) 
		{
			try {
			System.out.print("Do you wish to add a fruit(f), vegetable(v) or a preserve(p)? ");
			String user=scanner.next();

				if(user.equals("f")) 
				{
					inventory[numItems]=new Fruit();
					inventory[numItems].addItem(scanner);
					numItems++;
					cond=true;
				}else if(user.equals("v")) 
				{
					inventory[numItems]=new Vegetable();
					inventory[numItems].addItem(scanner);
					numItems++;
					cond=true;
				}else if(user.equals("p")) 
				{
					inventory[numItems]=new Preserve();
					inventory[numItems].addItem(scanner);
					numItems++;
					cond=true;
				}else 
				{
					throw new IllegalArgumentException("Invalid input");
				}
				
				
			
			}catch(IllegalArgumentException illg) 
			{
				System.out.println(illg.getMessage());
			}catch(InputMismatchException imm) 
			{
			  System.out.println("invalid input");	
			}
			
		}
		
		
		return cond;//return true after successful transction
		
	}//method ends
	
	
	
	
	/**
	 * This method will return the data saved in the class fields as string 
	 * @return String
	 * 
	 * */
	@Override
	public String toString() 
	{
		
		String print="Inventory\n";
		
		for(int i=0;i<numItems;i++) {
		 print+=inventory[i].toString()+"\n";
		
		}
		
	
		return print;//return print information
		}
	
	
	
	
	
	/**
	 * This method read from user to buy or sell from inventory then base on user choice.
	 * It reads item code from user and number of stock they bought or sell then update the inventory stock
	 * 
	 * @param scanner: Scanner
	 * @param buySell: boolean
	 * @return: boolean
	 * 
	 * 
	 * */
	public boolean updateQuantity(Scanner scanner, boolean buyOrSell) 
	{
		if(numItems==0) //if the index is 0 then return false nothing to buy or sell
		{
          return false;			
		} 
		
		Fooditem food=new Fooditem();//creating new object of Fooditem for asking item code and compare that to inventory
		
		
		food.inputCode(scanner);//read item code for the food object 
		int retn=alreadyExists(food);//return the the index if the code exist
		
		if(retn<0) 
		{
			System.out.println("Could not find the item :( ");//if index is not found the alreadyExist method return -1 and item is not found
			return false;
		}
		
		String option=buyOrSell? "buy" : "sell"; //String if buyOrSell is true assign buy else assign false;
		
		try {
		System.out.println("Enter the valid quantity to "+option);
		
		int quant=scanner.nextInt(); //input for the user
		
		if(quant<=0) 
		{
			System.out.println("Invalid quantity: ");//
			return false;
		}else 
		{
		
			boolean upbalance=buyOrSell;
			
			
			if(upbalance==false) {quant=quant*-1;}
			
			upbalance=inventory[retn].updateitem(quant);//upbalance true if quantity exist
			
			if(upbalance==false) 
			{
				System.out.println("Error.....could not sell item");
			}
			
			return upbalance;//return true if successful transction
		
			
		}
		}catch(InputMismatchException inp) 
		{
			System.out.println("Invalid input: ");
		}catch(Exception e) 
		{
			System.out.println("Exception ");
			return false;
		}
		
		return false;
		
		
		
		
		
	}
	
	
	
}//class ends 
