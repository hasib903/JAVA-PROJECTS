package lab4;
import java.util.Scanner;
/**
 * This class Person act as generic class. It contains all the personal information about 
 * the client. 
 * 
 * @author Hasibulla Yosufi
 * 
 * @since 1.0
 * 
 * @since 1.8
 * 
 * 
 * */
public class Person {
	//declaring my fields, will be use for user name, email, phone
	protected String firstName;
	protected String lastName;
	protected String email;
	protected long phoneNumber;


	/**
	 * This method returns first and last name of the user
	 * 
	 * @return String
	 * 
	 * 
	 * */
	protected String getName() {          //Protected access specifier so only its subclasses will have access 
		return firstName+" "+ lastName;  //getName will give full name of the user
	}


	/**
	 * This method will return user's email
	 * 
	 * @return String
	 * 
	 * */
	protected String getEmail() { //Protected access specifier so only its subclasses will have access 
		return email;
	}

	/**
	 * This method will return user's phone number 
	 * 
	 * @return long
	 * 
	 * 
	 * 
	 * */
	protected long getPhoneNumber() {//Protected access specifier so only its subclasses will have access
		return phoneNumber; //
	}


	/**
	 * This method will read personal information of the user, name, email, phoneNumber
	 * 
	 * @param Scanner
	 * 
	 * @return void
	 * 
	 * 
	 * */
	protected void readPersonalDetails(Scanner input)
	{

		System.out.print("Enter the name: ");        //asking for user first name
		firstName=input.next();                     //waiting for user input for fname String

		System.out.print("Enter the last name: "); //asking for user last name
		lastName=input.next();                    //asking for user input String

		System.out.print("Enter the email: ");     //asking for user email 
		email=input.next();						  //waiting for user to input email as String

		System.out.print("Enter the phone number: ");//asking for user phone number
		this.phoneNumber=input.nextLong();          //waiting for user to input phone number as integer (long)

	}


}
