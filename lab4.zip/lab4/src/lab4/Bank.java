package lab4;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * This class manipulates Accounts (Checking,Saving) using Polymorphiasm. 
 * Depending on user choice it will create ArrayList of Checking or Saving account.
 * 
 * @author Hasibullah Yosufi
 * @since 1.0
 * @version 1.8
 * 
 * 
 * 
 * 
 * */
public class Bank {
	//Declaring my instance variables for bank name 
	protected String name;
	protected ArrayList <Account> accounts=new ArrayList(); //Initializing ArrayList accounts to get access its elements

	// default constructor no parameterized 
	protected Bank() {};


	//paramaterized Constructor that will ask for name of the bank and setting size for our ArrayList
	protected Bank (String nameOfBank, int size)
	{

		this.name=nameOfBank;
		accounts= new ArrayList <Account> (size);
	}

	int j=0; //variable for index of our arraylist

	/**
	 * This method asks user about what type they want and based on their choice will make Checking or Saving
	 * 
	 * @param Scanner
	 * 
	 * @return void
	 * 
	 * 
	 * 
	 * */
	protected void readAccount(Scanner input) 
	{//start of method readAccount


		int userinput; //control variable for user give them option what to choose


		System.out.printf("%s%s","Enter your option: ","\n1.  Checking\n2.  Saving\n");//output for the user what types of account
		userinput=input.nextInt();	 //waiting for user input of their choice integer

		if (userinput==1)          //if input get 1 it will create space for checking account in ArrayList
		{
			accounts.add(new Checking());	
		}else if (userinput==2)   //else if user input=2 then create space for saving account with monthly interest
		{
			accounts.add(new Saving());//allocate space for  saving account 



		}//end of method



		accounts.get(j).readAccountDetails(input);//read the detail for the user.



		j++;
	}//end of method



	/**
	 * This method wll display user information first and last person.
	 * 
	 * @return void
	 * 
	 * 
	 * */
	protected void displayAccount() 
	{   

		if (accounts.isEmpty()) //if accounts is empty output the below
		{
			System.out.println("Nothing to display");
		}//end if

		else if(!(accounts.isEmpty())) {//if account is not empty then output the data

			printStar();//print line of starts
			System.out.printf("\n%16s  | %16s | %20s | %8s |%13s", "Acc Number","Name","Email", "Phone Number", "Balance\n");
			printStar();//print line of stars
			System.out.println();
			for (int i=0;i<j;i++)//for loop index of our array
			{		
				accounts.get(i).displayAccount();
			}//end of the loop

		}//end of else if
	}//end of the method







	/**
	 * This method does the monthly update interest for saving,
	 *  fees for saving
	 * 
	 * @return void
	 * 
	 * 
	 * */
	protected void runMonthlyProcess()
	{//method body starts

		if (accounts.isEmpty()) //if account is empty output the below
		{
			System.out.println("No account to process");
		}//end if statement

		else if (!(accounts.isEmpty())) {

			for (int i=0;i<j;i++)   //for loops  to get access to every index of ArrayList

			{
				accounts.get(i).updateBalance();//for loops for index of array
			}//end of loop

		}//end else if statement

	}//method end 



	/**
	 * This method does the monthly update interest for banking fees for saving
	 *  
	 * 
	 * @return void
	 * 
	 * 
	 * */
	protected static void printStar() 
	{
		for (int i=0;i<=90;i++) //loop for printStar metod. 

		{



			System.out.print("*");//print * in row
		}
	}




}
