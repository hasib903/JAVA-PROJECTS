package lab4;
import java.util.Scanner;
public class BankTest {
	public static void main(String[] args) {
		//declaring Scanner to read from user
		Scanner input=new Scanner(System.in);

		//Output ask the name of bank from user
		System.out.print("Enter the name of the bank: ");

		String bName=input.next();//user input for name of the bank

		//output ask for how many accounts user have
		System.out.print("How many account holders do you have: ");
		int accHold=input.nextInt();//user input for the number of accounts

		//Initializing my Bank object and invoking name and number of accounts in its argument
		Bank b=new Bank(bName,accHold);

		int userinput;//declaring integer variable for the user input

		do {

			//Output menu option for the user
			System.out.print("1. Read accounts\n2. Run monthly process\n3. Display Accounts\n"
					+ "4. Exit\nEnter your option: ");

			//while loop for the user if the input invalid value
			while (!(input.hasNextInt()))
			{
				System.out.println("invalid enter expecting integers!!! ");
				input.next();

			}//end while 


			userinput=input.nextInt();//input for user



			if (userinput==1)
			{
				b.readAccount(input);
			}//end if

			else if (userinput==3)
			{
				if(b.accounts.isEmpty()) 
				{
					System.out.println("Nothing to display");
				}else if(!(b.accounts.isEmpty())) {
				Bank.printStar();
				System.out.printf("\n%45s%s",bName.toUpperCase()," BANK\n");//prints line and name of the bank in upper case  
				b.displayAccount();
				}
			}//end else if

			else if (userinput==2)
			{
				b.runMonthlyProcess();
			}//end else if

			//if input is greater than 4 then output the belwom
			else if (userinput>4)
			{
				System.out.println("Invalid entry... plase try again");
			}//end else if



		}while (userinput!=4);



	}


}
