/**
 * This Person class is generic class which will be inherited by
 * Students, To read from user identification.
 * @author hasibyosufi
 * @version 1.8
 * @since 2.0
 * 
 */
import java.util.Scanner;
public abstract class Person {
   //Declaring my instance variables for user first name, last name, eamil, phone
	protected String fName;
	protected String lName;
	protected String email;
	protected long phone;
	
	
	
	
	public Person() {}

	/**
	 * readInfo method will be used to read from user
	 * 
	 * @return void
	 * 
	 * */
	public abstract void readInfo(Scanner input);
	
	/**
	 * printInfo method will be used to print user details 
	 * 
	 * @return void
	 * 
	 * */
	public abstract void printInfo();
	
	
	

}
