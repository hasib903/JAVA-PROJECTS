
/**
 * This class with the main method which executes the code inside main method cathch any possible exception and ask the user 
 * to try again
 *
 * 
 * @author hasibyosufi
 * 
 * @version 1.8
 * @since 2.0
 * 
 * 
 * 
 * */
//
//
import java.util.InputMismatchException;
import java.util.Scanner;
public class CollegeSystemTest {
//	
	public static void main(String [] args) throws Exception  
	{
		String name;//="";
		 Integer user=0;
		boolean con=true;
		
//		//declaring scanner for user
		Scanner input=new Scanner(System.in);
	
	
		System.out.print("Enter name of Collage: ");//asking user for name of the college
		
		name=input.next(); //input for the name of College
		
		
		do {
			try {	
				
				//asking for the user the number of students
				System.out.print("Enter number of Student: ");
				user=input.nextInt();
				if (user<1) 
				{
					//if user input is less than 1 than throw new exception for input cannot be less than 1
					throw new IllegalArgumentException ("Number of students should be positive... please try again!");
					
				}else //else if the condition is positive <0  invoke the number of students in constructor
   
					con=false;//boolean con becomes false when there are no Exception 
				
			}//end of try statement
			
			catch (InputMismatchException i) //Exception for invalid values others than integers 
			{
				//print the message in read line for mismatch input
				System.err.println("Input Mismatch Exception while reading user's "
						+ "choice in main menu... please try again!");
				
			          input.next(); //input for the user to try again after the invalid input	
			}//end of InputMismatchExcetion catch
			
			catch (IllegalArgumentException el) //Exception for the values less than 1 
			{
				System.out.println(el.getMessage());
			}//end of IllegalArgumentException 
			
		}while (con);//end of while loop 
			    
	    
	   College co=new College(name,user);//invoking name and number of students in the constructor
	   

	   
	   
	   
	   
	   
	   /*This part is before the today's morning above was commented 2020-07-25 11:46am*/
	   
	   boolean next=true;//boolean variable for do while loop condition
	   do {
		   
	   //prompt menu for the user to chose reading from keyboard or reading from the file and print the information   
	   System.out.print("1. Read students info from keyboard\n2. Read student info from file\n3. Print details of all Students\n"
	   		+ "4. To exit the program\n");
	   
	   System.out.print("Enter your option: ");//output for the user option 
	   
	  try { 
		  
	  
	    int userinput=input.nextInt();//input for the user to choose from menu option  
	    System.out.println("opt: "+userinput);//output the value entered bu the user
	    
	    if (userinput<1 || userinput>4)//if user input is not between 1-4 then throw Exception of illegal argument values
	    {
	    	//Throws exception if the user input is not between 1 up to 4 
	    	throw new IllegalArgumentException ("Invalid entery...selection option 1-4.... please try again! ");
	    }//end if
	    
	    
	    else if (userinput==1) //if user input =1 then sould read from keyboard
	    {
	    	co.ReadStudentsDetails(input);
	    }//end of else if 
	    
	    else if(userinput==2) 
	    {
	    	co.readFile();
	    	
	    }//end of else if 
	    else if(userinput==3) 
	    {
	    	co.printStudentDetial();
	    	
	    }
	    
	    
	    else if (userinput==4) 
    	{
    		next=false;
    		System.out.println("Good bye... have nice day (:  ");
    	}//end of else if
	    
	    
	    

	  }catch (InputMismatchException ms)//Exception for invalid values letters
	  {
		  System.err.println("Input Mismatch Exception while reading user's choice in main menu... please try again!");
		  input.next();
	  }//end of InputMismatchException
	  catch (IllegalArgumentException il)//exception for input values that are not betwenn 1-40
	  {
		  System.out.println(il.getMessage());
		  //input.next();
	  }//end of IllegalArgumentException
	  catch (IndexOutOfBoundsException inx)
	  {
		  System.out.println(inx.getMessage());
		
	  }//end of IndexOutOfBoundException catch

	   }while(next);//end of nested while loop

	   
	   
	  
	   
	   
//	   co.openFile();
	   
	   
	   
	   
//	   
//	/*###############################################################################################################*/   
//	}catch (InputMismatchException i) 
//	{
//		
//		System.err.println("Input Mismatch Exception while reading user's "
//				+ "choice in main menu... please try again!");
//		input.next();
//		//input.next();
//	}catch (IllegalArgumentException el) 
//			{
//		 		System.out.println(el.getMessage());
//		 		
//		 		
//		 		
//			}
//			
//	}while (con);
////		int userinput=0;//variable for user input
////		int con=1;
////		do {
////			try {
////			System.out.print("1. Read students info from "
////					+ "keybord\n2. print details of all students ");
////			
////			userinput=input.nextInt();
////			if (userinput==1) {
////				co.ReadStudentsDetails(input);
////				}else if(userinput==2) {
////				//calling printTile method to print the name with format
////				try {
////				co.printTitle();
////				co.printStudentDetial();
////				}catch (IndexOutOfBoundsException ie) 
////				{
////					System.err.println(ie.getMessage());
////				}//end of catch 
////				
////				}//end of else if
////				
////				
////			} catch(InputMismatchException e)
////			{
////				System.out.println("input is not valid please try again");
////			}
////		}while (con!=4);
////	
//		
//
//		
		input.close();
//		
	}
	
	
	

}
