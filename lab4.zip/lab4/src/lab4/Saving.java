package lab4;


/**
 * This Checking class inherits from Account class and implement its abstract method
 * to update account balance by applying monthly benefits and add that to the current balance
 * 
 * @author  Hasibullah Yosufi
 * @since   1.0 
 * @version 1.8
 * */
public class Saving extends Account{
	//declaring my instance variable for monthly interest
	protected double interestRate;
	
	//Constructor that initialize  interesRate to 3.99
	protected Saving()
	{
		this.interestRate=3.99;
	}

	/**
	 * This method update current balance by adding monthly benefits
	 * 
	 * @return void
	 * 
	 * 
	 * */
	@Override
	protected void updateBalance()
	{
		
		double interest=((super.balance*interestRate)/100)/12; //finding monthly interest useing the formula
		super.balance+=interest;                              //adding interest to the current balance.
	}

}
