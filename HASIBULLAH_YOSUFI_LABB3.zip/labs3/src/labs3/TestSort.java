package labs3;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.*;
public class TestSort {

	public static void main(String[] args) {		
		
		int numArr[]=new int[1000];
		SortingAlgorithm bin=new SortingAlgorithm();
		Scanner input=new Scanner(System.in);
			

			
  
       // bin.generatRandomsInts(numArr);
        
        

			
			
			
			
			
			
			
		int start=0;
		int end=numArr.length-1;
		
		boolean condition=true;



do 
			{
				try {
				System.out.println("Select your option in the menu");
				System.out.println("1.Initialize and populate an array of 1000 random integers");
				System.out.println("2.Perform recursive binary and linear search");
				System.out.println("3.Perform iterative binary and linear search");
				System.out.println("4. To sort array");
				System.out.println("5. To quit: ");		
						
						
						
				
				System.out.print(">");
				int choice=input.nextInt();
				 if(choice<1 || choice>5) 
				{
					throw new IllegalArgumentException("Plase choce betweeen 1 to 4");
				}else if(choice==1) {
				 
				bin.generatRandomsInts(numArr);
				}else if(choice==2) {
		
					System.out.print("Please enter an integer value to search: ");
					int userInput=input.nextInt();
		         	bin.recursiveBinarySearch(numArr, start, end, userInput);
					bin.recursiveLinearSearch(numArr, start, end, userInput);
					bin.remainingElements(numArr, userInput);
				}else if(choice==3) 
				{
					bin.iterativeBinarySearch(numArr, choice);
					bin.iterativeLinearSearch(numArr, choice);
				}else if(choice==4) 
				{
					boolean cn=true;
					do {
					
						System.out.println("B. For bubble sort");
						System.out.println("I. For Insertation sort");
						System.out.println("S. For Selection sort");
						System.out.println("M. For Merge sort");
						System.out.println("Q. For Quick sort");
						System.out.println("R: TO return main menu");
						System.out.print(">");
						String user=input.next();
						if(user.equals("B")) 
						{
							bin.bubbleeSort(numArr);
							bin.printArray(numArr);
							
						}else if(user.equals("I")) {
							
							bin.InsertationSort(numArr);
							bin.printArray(numArr);
							
						}else if(user.equals("S")) {
							bin.SelectionSort(numArr);
							bin.printArray(numArr);
						}else if(user.equals("M")) {
							bin.merge(numArr, 0, numArr.length-1);
							bin.printArray(numArr);
						}else if(user.equals("Q")) 
						{
							bin.quickSort(numArr, 0, numArr.length-1);
							bin.printArray(numArr);
						}else if(user.equals("r")) 
						{
						cn=false;	
						}
						
						
						
					}while(cn);
					
				}else if(choice==5) {
			
				
					condition=false;
					input.close();
				
				}
			
			}catch(IllegalArgumentException ill) {
				System.err.print("Please chose between 1 to 4\n");
		
				
			}catch(InputMismatchException inps) 
			{
				System.err.println("********Input mismatch Exception*****\n");
				input.next();
				
			}
			}while(condition);	
			
			
			
			
			
			
			
			
			
	}

}


