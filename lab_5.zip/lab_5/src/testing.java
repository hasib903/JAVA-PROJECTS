//import java.util.Scanner;
//public class testing {
//	public static void main(String[] args) {
//		
////	FulltimeStudent st= new FulltimeStudent();
////	st.readInfo();
////	st.printInfo();
////		ParttimeStudent pt=new ParttimeStudent();
//		
//		Scanner input=new Scanner(System.in);
////		
//		System.out.print("Enter name of Collage: ");
////	
//		String name=input.next();
//		System.out.print("Enter number of Student: ");
//	   int user=input.nextInt();
//		College co=new College(name,user);
////		
////		
////		
////		Students st=new Students();
////		st.readInfo();
////		st.printInfo();
////
////		
//		co.ReadStudentsDetails();
//		co.printTitle();
//		co.printStudentDetial();
//	
//
//		
//		input.close();
//		
//		
//	
		
//		st.readInfo();
//		st.printInfo();
		
//		
//		FulltimeStudent st= new FulltimeStudent();
//		st.readInfo();
//
//		ParttimeStudent pt=new ParttimeStudent();
//		pt.readInfo();
//		pt.printInfo();
//		st.printInfo();	
			
			
			
			
		
//		
//		
//	}
//
//}
