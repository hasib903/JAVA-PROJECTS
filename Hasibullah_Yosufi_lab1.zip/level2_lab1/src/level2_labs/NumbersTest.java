/*
 
 
    Name: Hasibullah Yosufi
    
    Professor: James Mwangi
    
    Section: CST8132_303
    
    Lab: lab 01
    
    Due date: 2021-05-23
  
  
  
  
 */



package level2_labs;
public class NumbersTest {
public static void main(String[] args) {
	//initializing and making object for Numbers 1d array
	Numbers n1=new Numbers(10);
	//generate numbers for n1 object
	n1.generateNumbers();
	System.out.println("Printing Numbers");
	
    n1.printNumbers();	
    
    //initializing and making object for Numbers 2d array
	Numbers n2=new Numbers(10,10);
	//Generating the squares of numbers for n2
	n2.generateSquares();
	//Print indices of each position 
	n2.printIndices();
	//print the squares of numbers in pattern
	n2.printSquares();
	//print start in pattern1
	n2.printStarsPattern1();
	//print star in pattern2
	n2.printStarsPattern2();
}
}
