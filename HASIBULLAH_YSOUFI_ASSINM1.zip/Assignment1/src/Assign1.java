import java.util.*;

/**
 * 
 * This class play with Inventory objects prompt menu for the user and read from user
 * @author yosu0001
 * @version 1.11
 * 
 * 
 * */
public class Assign1 {

	
	/**
	 * This method is for menu option for the user prompt
	 * @return void
	 * 
	 * 
	 * */
	public static void displayMenu()//menu option for the user 
	{
		System.out.println("Please select one of the followin: ");
		System.out.println("1. To add Item to inventory:");
		System.out.println("2. To Display current inventory:");
		System.out.println("3. To Buy items:");
		System.out.println("4. To Sell items:");
		System.out.println("5. To Exit: ");
		System.out.print("> ");
		
	}
	
	public static void main(String[] ags) 
	{
		

	
		
		
		Inventory inv=new Inventory();//initializing inventory
		Scanner input=new Scanner(System.in);//initializing Scanner 
		
		
		
		int choice=0;//choice for switch statement and control variable for the while loop
		
		while(choice!=5) {//while loop if user input is not 5
			
			try {
				displayMenu();//display menu option 
				choice=input.nextInt();//integer var reads from user
				switch(choice) 
				{
				case 1://add items to the inventory
					inv.addItem(input);
					break;
				case 2://show the element as string and print them all
					System.out.println(inv.toString());
					break;
				case 3://buy from inventory
					if(!inv.updateQuantity(input, true))
						System.out.println("Error....Could not buy item ");
					break;
				case 4://sell from inventory
					if(!inv.updateQuantity(input, false))
						System.out.println("Error...Could not sell item");
					break;
				
				case 5://exit from program
					System.out.println("Exiting....");
					input.close();//close the Scanner
					break;
				default://deafult if other values entered
					System.out.println("Wrong input");
				break;
				
				}
			}catch(InputMismatchException inp) //input mismatch
			{
				System.out.println("Invalid input");
				input.next();
			}catch(IllegalArgumentException ilg) 
			{
				System.out.println("Invalid input");
				input.next();
			}
			
			
			
		}
		
			
			
		
	
		
		
		
		
		
		
		
		
		
		
		
		
//	Fooditem fo=new Fooditem();
//	

//	
//	
//	fo.addItem(input);
	//boolean che=fo.inputCode(input);
	
//	System.out.println();
//
//	Fruit ve=new Fruit();
//	ve.addItem(input);
//	
//	System.out.println(ve.toString());
//	//fo.addItem(input);
	int x=-1;
	
	System.out.println(12+x);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		Fooditem fo=new Fooditem(100,"Apple");
//		Fooditem fo2=new Fooditem(100,"Orange");
//		Fooditem fo3=new Fooditem(200,"Orange");
//		
//		
//		System.out.println(" "+fo.isEqual(fo2));
//		System.out.println(" "+fo.isEqual(fo3));
		
		
	}
}
