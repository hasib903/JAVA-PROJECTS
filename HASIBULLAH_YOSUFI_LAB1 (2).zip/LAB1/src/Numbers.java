import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * This class contains the dynamically allocated array and it's processing
 * Student Name: Hasibullah Yosufi
 * Student Number: 041012318
 * Course: CST8130 - Data Structures
 * CET-CS-Level 3
 * @author/Professor James Mwangi PhD. 
 * 
  */
public class Numbers {
	/**
	 * Stores Float values.
	 */
	private Float [] numbers=new Float[10];
	
	/**
	 * Store the number of items currently in the array.
	 */
	private int numItems=0; //initialize it to zero to use it in addValue method

	/**
	 * Default Constructor
	 */
	public Numbers() {
		// TODO Write code here to initialize a "default" array since this is the default constructor
	}

	/**
	 * Constructor that initializes the numbers array.
	 * @param size - Max size of the numbers array
	 */
	public Numbers(int size) {
		// TODO Write code here to initialize the numbers array of max 'size'
		numbers=new Float[size];
	}
	
	/**
	 * Adds a value in the array
	 * @param keyboard - Scanner object to use for input
	 */
	public void addValue(Scanner keyboard) {
		try {//Start of try catch statement
		
			
		
		System.out.print("Enter the value: "); //asking the user for value the want to insert in array of numbers
		
		
			numbers[numItems]=keyboard.nextFloat(); //initializing the user input into the index array numbers 
			numItems++; //incrementing numItems by 1
		}catch(IndexOutOfBoundsException ion) 
		{
			System.out.println("Out of bound");
		}
		
	}
	
	/**
	 * Calculates the average of all the values in the numbers array.
	 * @return float value that represents the average
	 */
	public float calcAverage() {
		// TODO Write code to return the average of the values in the array
		
		 Float sum=0.0f; //variable to save the total sum of the array numbers
		 Float average=0.0f;//Variable to save the average of numbers
		try {
			Float min=numbers[0];//variable to find the minimum value of the array
			Float max=numbers[0];//varibale to find the maximum value of the array
		
			for(int i=0;i<numItems;i++) {
			
				if (numbers[i]<min) //if condition that find the minimum value from the array
					{
						min=numbers[i];
					}
					if (numbers[i]>max) //if statement that find the maximum value from the array
					{
						max=numbers[i];
					}
			sum=sum+numbers[i];//calculating the total sum of the values in the array of numbers
			
			}
			
		average=sum/numItems;//calculate the average value from the numbers array
			
		//output the average value, maximum and minimum value of the array
		 System.out.printf("Average value: %.2f, Min value: %.2f, Max value: %.2f \n",average,min,max);
				
		
		}catch(IndexOutOfBoundsException ie)
		{
			System.out.println("Array is full");
		}catch(InputMismatchException inp) 
		{
			System.out.println("Wrong data Type ;( ");
			
		}catch(NullPointerException e)
		{
			System.out.println("no index value ");
		}catch(Exception ed) {
			System.out.println("Exception happened");
		}
	    
		
	
		
		return average;//return average 
	}

	/**
	 * Prints every elements of the array
	 * 
	 * @return void 
	 * 
	 * */
	public void showElements() {
	try {
		for (int i=0;i<numbers.length;i++) 
		{
			System.out.println(numbers[i]);
		}
	}catch(NullPointerException nlp) 
	{
	System.out.println("Numbers are: ");	
	}
		
	}
	

	
}
