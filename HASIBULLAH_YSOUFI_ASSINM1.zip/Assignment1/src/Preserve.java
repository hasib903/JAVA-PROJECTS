import java.util.*;



/**
 * 
 * This class extends Fooditems and and have field for size in mills call its parent class method override them
 * @author khesr
 * @since 2021-10-02
 * @version 1.8
 * 
 * 
 * */
public class Preserve extends Fooditem {
	
	
	private int jarSize;//field for the amount size of jars in mll
	
	
	/**
	 * This method return string format of fields calls its super class method
	 * @return String
	 * 
	 * 
	 * */
	@Override
	public String toString() 
	{
		
		String mustReturn=super.toString()+" size: "+this.jarSize+"ml ]";
		return mustReturn;
		
	}
	
	/**
	 * This method addItem to inventory reads from keyboard calls its super class method
	 * @param scanner: Scanner
	 * 
	 * 
	 * */
	@Override
	public boolean addItem(Scanner scanner) 
	{
		boolean cond=false;
		while (!cond) 
		{
		super.addItem(scanner);
		System.out.print("Enter the size of the jar in millilitres: ");
		this.jarSize=scanner.nextInt();
		cond=true;
		}
		
		return cond;
	}
	
	
	
	
	
	
	
	
	
	

}
